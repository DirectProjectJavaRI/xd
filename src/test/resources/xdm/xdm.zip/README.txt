NHIN Direct - IHE Team - Implementation. 

This XDM message was created via the web interface.aa  
Please view INDEX.HTM for links to the files and metadata that make up this message.